import { createBrowserRouter } from "react-router";
import { JurisdictionSelection } from "./components/JurisdictionSelection";
import { UnifiedLogin } from "./components/UnifiedLogin";
import { RoleSelection } from "./components/RoleSelection";
import { PublicReporter } from "./components/PublicReporter";
import { CleanerPortal } from "./components/CleanerPortal";
import { AdminDashboard } from "./components/AdminDashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: JurisdictionSelection,
  },
  {
    path: "/login",
    Component: UnifiedLogin,
  },
  {
    path: "/role-select",
    Component: RoleSelection,
  },
  {
    path: "/reporter",
    Component: PublicReporter,
  },
  {
    path: "/cleaner",
    Component: CleanerPortal,
  },
  {
    path: "/admin",
    Component: AdminDashboard,
  },
]);