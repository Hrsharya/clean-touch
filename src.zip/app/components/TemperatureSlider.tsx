import { useState, useRef, useEffect } from "react";
import { motion } from "motion/react";

interface TemperatureSliderProps {
  value: number;
  onChange: (value: number) => void;
}

export function TemperatureSlider({ value, onChange }: TemperatureSliderProps) {
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Temperature range: 5°C to 35°C
  const minTemp = 5;
  const maxTemp = 35;
  
  // Convert temperature to angle (0° at top, going clockwise)
  const tempToAngle = (temp: number) => {
    const normalized = (temp - minTemp) / (maxTemp - minTemp);
    return normalized * 270 - 135; // -135° to 135° range
  };

  const angle = tempToAngle(value);

  const handleInteraction = (clientX: number, clientY: number) => {
    if (!containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const deltaX = clientX - centerX;
    const deltaY = clientY - centerY;

    let angleRad = Math.atan2(deltaY, deltaX);
    let angleDeg = angleRad * (180 / Math.PI);

    // Convert to our coordinate system (0° at top)
    angleDeg = angleDeg + 90;
    
    // Normalize to -135° to 135° range
    if (angleDeg > 135) angleDeg = 135;
    if (angleDeg < -135) angleDeg = -135;

    // Convert angle back to temperature
    const normalized = (angleDeg + 135) / 270;
    const newTemp = Math.round(minTemp + normalized * (maxTemp - minTemp));
    
    onChange(Math.max(minTemp, Math.min(maxTemp, newTemp)));
  };

  const handleMouseDown = () => setIsDragging(true);
  
  const handleMouseUp = () => setIsDragging(false);

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging) {
      handleInteraction(e.clientX, e.clientY);
    }
  };

  const handleTouchMove = (e: TouchEvent) => {
    if (isDragging && e.touches[0]) {
      handleInteraction(e.touches[0].clientX, e.touches[0].clientY);
    }
  };

  useEffect(() => {
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
    document.addEventListener("touchmove", handleTouchMove);
    document.addEventListener("touchend", handleMouseUp);

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.removeEventListener("touchmove", handleTouchMove);
      document.removeEventListener("touchend", handleMouseUp);
    };
  }, [isDragging]);

  // Get gradient color based on temperature
  const getGradientColor = () => {
    const normalized = (value - minTemp) / (maxTemp - minTemp);
    if (normalized < 0.33) {
      return "from-blue-400 via-cyan-400 to-blue-300"; // Cold
    } else if (normalized < 0.66) {
      return "from-cyan-400 via-green-400 to-emerald-400"; // Cool
    } else {
      return "from-emerald-400 via-orange-400 to-orange-500"; // Warm
    }
  };

  return (
    <div className="flex flex-col items-center" ref={containerRef}>
      {/* Circular slider */}
      <div className="relative w-48 h-48">
        {/* Background circle track */}
        <svg className="absolute inset-0 w-full h-full -rotate-[135deg]">
          <circle
            cx="96"
            cy="96"
            r="80"
            fill="none"
            stroke="rgba(255, 255, 255, 0.1)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray="377"
            strokeDashoffset="94.25"
          />
        </svg>

        {/* Active progress circle */}
        <svg className="absolute inset-0 w-full h-full -rotate-[135deg]">
          <defs>
            <linearGradient id="tempGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3B82F6" />
              <stop offset="50%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#F97316" />
            </linearGradient>
          </defs>
          <motion.circle
            cx="96"
            cy="96"
            r="80"
            fill="none"
            stroke="url(#tempGradient)"
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray="377"
            initial={false}
            animate={{
              strokeDashoffset: 377 - (377 * ((angle + 135) / 270)) + 94.25,
            }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          />
        </svg>

        {/* Center display */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <motion.div
              className="text-4xl text-white"
              key={value}
              initial={{ scale: 1.2, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.2 }}
            >
              {value}°
            </motion.div>
          </div>
        </div>

        {/* Draggable handle */}
        <motion.div
          className="absolute top-1/2 left-1/2 cursor-grab active:cursor-grabbing"
          style={{
            x: "-50%",
            y: "-50%",
          }}
          animate={{
            rotate: angle,
          }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          onMouseDown={handleMouseDown}
          onTouchStart={handleMouseDown}
        >
          <motion.div
            className="relative"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            style={{ translateY: -80 }}
          >
            {/* Particle trail effect when dragging */}
            {isDragging && (
              <motion.div
                initial={{ scale: 0, opacity: 1 }}
                animate={{ scale: 2, opacity: 0 }}
                transition={{ duration: 0.5, repeat: Infinity }}
                className={`absolute inset-0 rounded-full bg-gradient-to-r ${getGradientColor()} blur-md`}
              />
            )}
            
            <div className="relative w-6 h-6 rounded-full bg-gradient-to-br from-white to-emerald-200 shadow-lg border-2 border-white/50">
              <motion.div
                animate={{
                  boxShadow: [
                    "0 0 10px rgba(16, 185, 129, 0.5)",
                    "0 0 20px rgba(16, 185, 129, 0.8)",
                    "0 0 10px rgba(16, 185, 129, 0.5)",
                  ],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute inset-0 rounded-full"
              />
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Temperature labels */}
      <div className="flex justify-between w-full mt-4 px-4 text-xs text-white/60">
        <span>Cold (5°C)</span>
        <span>Warm (35°C)</span>
      </div>
    </div>
  );
}
