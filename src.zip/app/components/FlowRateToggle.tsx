import { motion } from "motion/react";
import { Waves, Droplets } from "lucide-react";

interface FlowRateToggleProps {
  isFlowing: boolean;
  flowRate: number;
  onToggle: (value: boolean) => void;
  onFlowRateChange: (value: number) => void;
}

export function FlowRateToggle({
  isFlowing,
  flowRate,
  onToggle,
  onFlowRateChange,
}: FlowRateToggleProps) {
  const flowRates = [
    { value: 1.5, label: "Low" },
    { value: 2.5, label: "Medium" },
    { value: 3.5, label: "High" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Waves className="w-5 h-5 text-emerald-400" />
          <h3 className="text-white/90 text-sm">Flow Control</h3>
        </div>
        
        {/* Main toggle button */}
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => onToggle(!isFlowing)}
          className="relative"
        >
          <motion.div
            animate={{
              backgroundColor: isFlowing
                ? "rgba(16, 185, 129, 0.3)"
                : "rgba(255, 255, 255, 0.1)",
              borderColor: isFlowing
                ? "rgba(16, 185, 129, 0.5)"
                : "rgba(255, 255, 255, 0.2)",
            }}
            className="w-16 h-8 rounded-full border-2 flex items-center px-1"
          >
            {/* Flash effect on toggle */}
            {isFlowing && (
              <motion.div
                initial={{ opacity: 1 }}
                animate={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0 rounded-full border-2 border-white"
              />
            )}
            
            <motion.div
              animate={{
                x: isFlowing ? 32 : 0,
                backgroundColor: isFlowing ? "#10B981" : "#ffffff40",
              }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
              className="w-6 h-6 rounded-full shadow-lg"
            >
              {isFlowing && (
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [1, 0.5, 1],
                  }}
                  transition={{
                    duration: 1,
                    repeat: Infinity,
                  }}
                  className="w-full h-full rounded-full bg-emerald-400/50"
                />
              )}
            </motion.div>
          </motion.div>
        </motion.button>
      </div>

      {/* Flow rate display */}
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{
          opacity: isFlowing ? 1 : 0.5,
          height: "auto",
        }}
        className="space-y-3"
      >
        <div className="flex items-center justify-between">
          <span className="text-white/70 text-sm">Flow Rate</span>
          <span className="text-emerald-400 text-lg">{flowRate} L/min</span>
        </div>

        {/* Flow rate selector buttons */}
        <div className="flex gap-2">
          {flowRates.map((rate) => (
            <motion.button
              key={rate.value}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onFlowRateChange(rate.value)}
              disabled={!isFlowing}
              className="flex-1"
            >
              <motion.div
                animate={{
                  backgroundColor:
                    flowRate === rate.value && isFlowing
                      ? "rgba(16, 185, 129, 0.3)"
                      : "rgba(255, 255, 255, 0.05)",
                  borderColor:
                    flowRate === rate.value && isFlowing
                      ? "rgba(16, 185, 129, 0.5)"
                      : "rgba(255, 255, 255, 0.1)",
                }}
                className="py-2 px-3 rounded-xl border backdrop-blur-sm transition-all"
              >
                {/* Glow effect for active button */}
                {flowRate === rate.value && isFlowing && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="absolute inset-0 rounded-xl bg-emerald-400/20 blur-md"
                  />
                )}
                
                <div className="relative flex flex-col items-center gap-1">
                  <Droplets
                    className={`w-4 h-4 ${
                      flowRate === rate.value && isFlowing
                        ? "text-emerald-400"
                        : "text-white/40"
                    }`}
                  />
                  <span
                    className={`text-xs ${
                      flowRate === rate.value && isFlowing
                        ? "text-emerald-400"
                        : "text-white/60"
                    }`}
                  >
                    {rate.label}
                  </span>
                </div>
              </motion.div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Water animation indicators */}
      {isFlowing && (
        <div className="relative h-12 flex items-end justify-around">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              initial={{ height: 0 }}
              animate={{ height: ["0%", "100%", "0%"] }}
              transition={{
                duration: 1,
                repeat: Infinity,
                delay: i * 0.1,
                ease: "easeInOut",
              }}
              className="w-1 bg-gradient-to-t from-emerald-400 to-emerald-300 rounded-full"
              style={{ opacity: 0.6 }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
