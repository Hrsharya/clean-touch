import { motion } from "motion/react";
import { Camera, Trash2, BarChart3 } from "lucide-react";
import { useNavigate } from "react-router";

export function RoleSelection() {
  const navigate = useNavigate();

  const roles = [
    {
      id: "reporter",
      title: "Citizen Reporter",
      description: "Report waste in your area",
      icon: Camera,
      color: "from-emerald-500/20 to-green-400/10",
      path: "/reporter",
    },
    {
      id: "cleaner",
      title: "Service Worker",
      description: "Complete cleaning tasks",
      icon: Trash2,
      color: "from-white/10 to-white/5",
      path: "/cleaner",
    },
    {
      id: "admin",
      title: "Administrator",
      description: "Oversee operations",
      icon: BarChart3,
      color: "from-emerald-500/30 to-emerald-400/10",
      path: "/admin",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A192F] via-[#0D1F38] to-[#0A192F] flex items-center justify-center p-6">
      {/* Animated background ripples */}
      <motion.div
        className="absolute inset-0 opacity-20"
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, rgba(80, 200, 120, 0.3) 0%, transparent 50%),
                           radial-gradient(circle at 80% 50%, rgba(144, 238, 144, 0.2) 0%, transparent 50%)`,
          backgroundSize: "200% 200%",
        }}
      />

      <div className="relative z-10 max-w-md w-full">
        {/* Logo and Title */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          {/* Logo - Touch ripple transforming to leaf */}
          <motion.div
            className="relative w-24 h-24 mx-auto mb-6"
            animate={{
              scale: [1, 1.05, 1],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            {/* Ripple circles */}
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-[#90EE90]"
              animate={{
                scale: [1, 1.3, 1.6],
                opacity: [0.8, 0.4, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeOut",
              }}
            />
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-[#90EE90]"
              animate={{
                scale: [1, 1.3, 1.6],
                opacity: [0.8, 0.4, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: 0.5,
                ease: "easeOut",
              }}
            />
            
            {/* Central leaf/touch icon */}
            <div className="absolute inset-0 flex items-center justify-center bg-[#50C878]/20 backdrop-blur-xl rounded-full border border-[#50C878]/40">
              <svg
                className="w-12 h-12 text-[#50C878]"
                viewBox="0 0 24 24"
                fill="currentColor"
              >
                <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.67C7.89 16.84 9.89 11 17 9V8zm-1-1.5c-7 2-9.1 7.83-11.18 13L3 21.84c2.09-5.17 4.09-11 11.18-13L14 6.5z" />
                <path d="M18.5 2c-2 0-4.37 1.5-5.5 3.5C11.87 3.5 9.5 2 7.5 2 5 2 3 4 3 6.5c0 3.38 3 6.5 10 11.5 7-5 10-8.12 10-11.5C23 4 21 2 18.5 2z" />
              </svg>
            </div>
          </motion.div>

          <h1 className="text-4xl text-white mb-2">Clean Touch</h1>
          <p className="text-white/60">Waste Management Ecosystem</p>
        </motion.div>

        {/* Role Cards */}
        <div className="space-y-4">
          {roles.map((role, index) => (
            <motion.button
              key={role.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 + 0.3 }}
              whileHover={{ scale: 1.02, x: 4 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate(role.path)}
              className="w-full group relative"
            >
              <motion.div
                animate={{
                  boxShadow: [
                    "0 0 20px rgba(80, 200, 120, 0.2)",
                    "0 0 30px rgba(80, 200, 120, 0.3)",
                    "0 0 20px rgba(80, 200, 120, 0.2)",
                  ],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className={`bg-gradient-to-br ${role.color} backdrop-blur-xl border border-white/20 group-hover:border-[#50C878]/50 rounded-2xl p-6 flex items-center gap-4 transition-all`}
              >
                {/* Hover glow effect */}
                <motion.div
                  initial={{ opacity: 0 }}
                  whileHover={{ opacity: 1 }}
                  className="absolute inset-0 bg-gradient-to-br from-[#50C878]/10 to-transparent rounded-2xl"
                />

                <div className="relative flex-shrink-0 w-14 h-14 bg-[#50C878]/20 backdrop-blur-sm rounded-xl flex items-center justify-center border border-[#50C878]/30 group-hover:border-[#50C878]/60 transition-all">
                  <role.icon className="w-7 h-7 text-[#90EE90] group-hover:text-[#50C878] transition-colors" />
                </div>

                <div className="flex-1 text-left">
                  <h3 className="text-white text-lg mb-1">{role.title}</h3>
                  <p className="text-white/60 text-sm">{role.description}</p>
                </div>

                <motion.div
                  animate={{
                    x: [0, 4, 0],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="text-[#90EE90]"
                >
                  →
                </motion.div>
              </motion.div>
            </motion.button>
          ))}
        </div>

        {/* Footer Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-8 flex justify-center gap-6 text-center"
        >
          <div>
            <div className="text-2xl text-[#50C878]">2,847</div>
            <div className="text-xs text-white/50">Reports</div>
          </div>
          <div className="w-px bg-white/20" />
          <div>
            <div className="text-2xl text-[#90EE90]">98%</div>
            <div className="text-xs text-white/50">Resolved</div>
          </div>
          <div className="w-px bg-white/20" />
          <div>
            <div className="text-2xl text-[#50C878]">156</div>
            <div className="text-xs text-white/50">Active Cleaners</div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
