import { useState } from "react";
import { motion } from "motion/react";
import { MapPin, Radar, ChevronDown } from "lucide-react";
import { useNavigate } from "react-router";

export function JurisdictionSelection() {
  const navigate = useNavigate();
  const [isDetecting, setIsDetecting] = useState(false);
  const [formData, setFormData] = useState({
    state: "",
    district: "",
    type: "",
    ward: "",
  });

  const states = ["Maharashtra", "Karnataka", "Delhi", "Tamil Nadu", "Gujarat"];
  const districts = ["Mumbai", "Pune", "Thane", "Nashik", "Nagpur"];
  const types = ["Urban", "Rural"];
  const wards = ["Ward A", "Ward B", "Ward C", "Block 1", "Block 2"];

  const handleDetectLocation = () => {
    setIsDetecting(true);
    // Simulate location detection
    setTimeout(() => {
      setFormData({
        state: "Maharashtra",
        district: "Mumbai",
        type: "Urban",
        ward: "Ward A",
      });
      setIsDetecting(false);
    }, 2000);
  };

  const handleContinue = () => {
    if (formData.state && formData.district && formData.type && formData.ward) {
      navigate("/login");
    }
  };

  const isFormComplete =
    formData.state && formData.district && formData.type && formData.ward;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A192F] via-[#0D1F38] to-[#0A192F] relative overflow-hidden flex items-center justify-center p-6">
      {/* Glowing emerald digital map background */}
      <motion.div
        className="absolute inset-0"
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%"],
        }}
        transition={{
          duration: 30,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        style={{
          backgroundImage: `radial-gradient(circle at 30% 40%, rgba(80, 200, 120, 0.15) 0%, transparent 40%),
                           radial-gradient(circle at 70% 60%, rgba(144, 238, 144, 0.1) 0%, transparent 40%)`,
          backgroundSize: "200% 200%",
        }}
      />

      {/* Map grid overlay */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `linear-gradient(rgba(80, 200, 120, 0.3) 1px, transparent 1px),
                           linear-gradient(90deg, rgba(80, 200, 120, 0.3) 1px, transparent 1px)`,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Floating location markers */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            opacity: [0.3, 0.6, 0.3],
            scale: [1, 1.2, 1],
            y: [0, -20, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            delay: i * 0.6,
          }}
          className="absolute"
          style={{
            left: `${20 + i * 15}%`,
            top: `${30 + i * 10}%`,
          }}
        >
          <MapPin className="w-6 h-6 text-[#50C878]" />
        </motion.div>
      ))}

      {/* Main Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="relative z-10 w-full max-w-md"
      >
        {/* Crystal glass modal */}
        <motion.div
          animate={{
            boxShadow: [
              "0 0 40px rgba(80, 200, 120, 0.3)",
              "0 0 60px rgba(80, 200, 120, 0.4)",
              "0 0 40px rgba(80, 200, 120, 0.3)",
            ],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="bg-white/5 backdrop-blur-xl border-2 border-white/20 rounded-3xl p-8"
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <MapPin className="w-16 h-16 text-[#50C878] mx-auto mb-4" />
            </motion.div>
            <h1 className="text-3xl text-white mb-2">Select Jurisdiction</h1>
            <p className="text-white/60">
              Localize your experience for better service
            </p>
          </div>

          {/* Form Fields */}
          <div className="space-y-4 mb-6">
            <DropdownField
              label="State"
              value={formData.state}
              options={states}
              onChange={(value) =>
                setFormData({ ...formData, state: value })
              }
              placeholder="Select State"
            />

            <DropdownField
              label="District"
              value={formData.district}
              options={districts}
              onChange={(value) =>
                setFormData({ ...formData, district: value })
              }
              placeholder="Select District"
              disabled={!formData.state}
            />

            <DropdownField
              label="Area Type"
              value={formData.type}
              options={types}
              onChange={(value) => setFormData({ ...formData, type: value })}
              placeholder="Urban/Rural"
              disabled={!formData.district}
            />

            <DropdownField
              label="Ward/Block"
              value={formData.ward}
              options={wards}
              onChange={(value) => setFormData({ ...formData, ward: value })}
              placeholder="Select Ward/Block"
              disabled={!formData.type}
            />
          </div>

          {/* Detect Location Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleDetectLocation}
            disabled={isDetecting}
            className="w-full mb-4 relative"
          >
            <motion.div
              animate={{
                boxShadow: isDetecting
                  ? [
                      "0 0 20px rgba(144, 238, 144, 0.4)",
                      "0 0 40px rgba(144, 238, 144, 0.6)",
                      "0 0 20px rgba(144, 238, 144, 0.4)",
                    ]
                  : "0 0 10px rgba(144, 238, 144, 0.2)",
              }}
              transition={{
                duration: 1,
                repeat: isDetecting ? Infinity : 0,
              }}
              className="bg-gradient-to-r from-[#90EE90]/20 to-[#50C878]/20 backdrop-blur-sm border border-[#90EE90]/40 rounded-2xl py-4 flex items-center justify-center gap-3"
            >
              {/* Radar pulse animation */}
              {isDetecting && (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{
                    scale: [0.8, 1.5, 2],
                    opacity: [0.6, 0.3, 0],
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeOut",
                  }}
                  className="absolute inset-0 rounded-2xl border-2 border-[#90EE90]"
                />
              )}
              
              <motion.div
                animate={isDetecting ? { rotate: 360 } : {}}
                transition={{
                  duration: 2,
                  repeat: isDetecting ? Infinity : 0,
                  ease: "linear",
                }}
              >
                <Radar className="w-6 h-6 text-[#90EE90]" />
              </motion.div>
              <span className="text-white relative z-10">
                {isDetecting ? "Detecting..." : "Detect My Location"}
              </span>
            </motion.div>
          </motion.button>

          {/* Continue Button */}
          <motion.button
            whileHover={isFormComplete ? { scale: 1.02 } : {}}
            whileTap={isFormComplete ? { scale: 0.98 } : {}}
            onClick={handleContinue}
            disabled={!isFormComplete}
            className={`w-full py-4 rounded-2xl text-white transition-all ${
              isFormComplete
                ? "bg-gradient-to-r from-[#50C878] to-[#90EE90] shadow-lg"
                : "bg-white/10 cursor-not-allowed opacity-50"
            }`}
          >
            Continue
          </motion.button>

          {/* Selected info */}
          {isFormComplete && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 bg-[#50C878]/10 backdrop-blur-sm border border-[#50C878]/20 rounded-xl"
            >
              <p className="text-white/80 text-sm text-center">
                Selected: {formData.state}, {formData.district},{" "}
                {formData.type}, {formData.ward}
              </p>
            </motion.div>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}

function DropdownField({
  label,
  value,
  options,
  onChange,
  placeholder,
  disabled = false,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
  placeholder: string;
  disabled?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const isActive = value !== "" || isOpen;

  return (
    <div className="relative">
      <label className="block text-white/70 text-sm mb-2">{label}</label>
      <motion.button
        whileHover={!disabled ? { scale: 1.01 } : {}}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        animate={{
          borderColor: isActive
            ? "rgba(80, 200, 120, 0.5)"
            : "rgba(255, 255, 255, 0.2)",
          boxShadow: isActive
            ? "0 0 20px rgba(80, 200, 120, 0.3)"
            : "0 0 0px transparent",
        }}
        className={`w-full bg-white/5 backdrop-blur-sm border-2 rounded-xl px-4 py-3 flex items-center justify-between transition-all ${
          disabled ? "opacity-40 cursor-not-allowed" : ""
        }`}
      >
        <span className={value ? "text-white" : "text-white/50"}>
          {value || placeholder}
        </span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown
            className={`w-5 h-5 ${
              isActive ? "text-[#50C878]" : "text-white/50"
            }`}
          />
        </motion.div>
      </motion.button>

      {/* Dropdown menu */}
      {isOpen && !disabled && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="absolute z-20 w-full mt-2 bg-[#0A192F]/95 backdrop-blur-xl border border-[#50C878]/30 rounded-xl overflow-hidden shadow-2xl"
        >
          {options.map((option) => (
            <motion.button
              key={option}
              whileHover={{
                backgroundColor: "rgba(80, 200, 120, 0.2)",
              }}
              onClick={() => {
                onChange(option);
                setIsOpen(false);
              }}
              className="w-full px-4 py-3 text-left text-white hover:text-[#90EE90] transition-colors border-b border-white/5 last:border-b-0"
            >
              {option}
            </motion.button>
          ))}
        </motion.div>
      )}
    </div>
  );
}
