import { motion } from "motion/react";
import { Coffee, Milk, CookingPot } from "lucide-react";

interface QuickPresetsProps {
  onSelect: (preset: string) => void;
}

export function QuickPresets({ onSelect }: QuickPresetsProps) {
  const presets = [
    { id: "glass", label: "Glass", icon: Coffee, amount: "250ml" },
    { id: "pitcher", label: "Pitcher", icon: Milk, amount: "1L" },
    { id: "pot", label: "Pot", icon: CookingPot, amount: "2L" },
  ];

  return (
    <div className="bg-white/5 backdrop-blur-xl border border-emerald-400/30 rounded-3xl p-6">
      <h3 className="text-white/90 text-sm mb-4">Quick Fill Presets</h3>
      
      <div className="grid grid-cols-3 gap-3">
        {presets.map((preset, index) => (
          <motion.button
            key={preset.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelect(preset.id)}
            className="relative group"
          >
            <motion.div
              whileHover={{
                boxShadow: [
                  "0 0 15px rgba(16, 185, 129, 0.3)",
                  "0 0 25px rgba(16, 185, 129, 0.5)",
                  "0 0 15px rgba(16, 185, 129, 0.3)",
                ],
              }}
              transition={{ duration: 1, repeat: Infinity }}
              className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm border border-white/20 group-hover:border-emerald-400/50 rounded-2xl p-4 flex flex-col items-center gap-2 transition-all"
            >
              {/* Hover glow effect */}
              <motion.div
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
                className="absolute inset-0 bg-gradient-to-br from-emerald-400/10 to-transparent rounded-2xl"
              />
              
              <div className="relative">
                <preset.icon className="w-8 h-8 text-emerald-400 group-hover:text-emerald-300 transition-colors" />
                
                {/* Ripple effect on hover */}
                <motion.div
                  initial={{ scale: 0, opacity: 0.5 }}
                  whileHover={{
                    scale: [1, 1.5],
                    opacity: [0.5, 0],
                  }}
                  transition={{ duration: 0.6, repeat: Infinity }}
                  className="absolute inset-0 rounded-full border-2 border-emerald-400"
                />
              </div>
              
              <div className="relative text-center">
                <div className="text-white/90 text-xs group-hover:text-white transition-colors">
                  {preset.label}
                </div>
                <div className="text-emerald-400/70 text-[10px] mt-0.5">
                  {preset.amount}
                </div>
              </div>
            </motion.div>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
