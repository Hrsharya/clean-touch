import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Smartphone,
  Briefcase,
  Shield,
  Fingerprint,
  QrCode,
  ArrowLeft,
} from "lucide-react";
import { useNavigate } from "react-router";

type RoleTab = "citizen" | "worker" | "admin";

export function UnifiedLogin() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<RoleTab>("citizen");
  const [citizenPhone, setCitizenPhone] = useState("");
  const [workerID, setWorkerID] = useState("");
  const [adminID, setAdminID] = useState("");
  const [showOTP, setShowOTP] = useState(false);
  const [otp, setOTP] = useState("");

  const tabs = [
    {
      id: "citizen" as RoleTab,
      label: "Citizen Access",
      icon: Smartphone,
      color: "#90EE90",
    },
    {
      id: "worker" as RoleTab,
      label: "Service Worker",
      icon: Briefcase,
      color: "#50C878",
    },
    {
      id: "admin" as RoleTab,
      label: "Admin Command",
      icon: Shield,
      color: "#50C878",
    },
  ];

  const handleCitizenLogin = () => {
    if (citizenPhone.length === 10) {
      setShowOTP(true);
    }
  };

  const handleOTPVerify = () => {
    if (otp.length === 6) {
      navigate("/reporter");
    }
  };

  const handleWorkerLogin = () => {
    if (workerID) {
      navigate("/cleaner");
    }
  };

  const handleAdminLogin = () => {
    if (adminID) {
      navigate("/admin");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A192F] via-[#0D1F38] to-[#0A192F] relative overflow-hidden flex items-center justify-center p-6">
      {/* Moving emerald light streaks */}
      <motion.div
        className="absolute inset-0 opacity-20"
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        style={{
          backgroundImage: `linear-gradient(45deg, transparent 30%, rgba(80, 200, 120, 0.3) 50%, transparent 70%),
                           linear-gradient(-45deg, transparent 30%, rgba(144, 238, 144, 0.2) 50%, transparent 70%)`,
          backgroundSize: "200% 200%",
        }}
      />

      <div className="relative z-10 w-full max-w-lg">
        {/* Back button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => navigate("/")}
          className="mb-6 p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </motion.button>

        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl text-white mb-2">Clean Touch</h1>
          <p className="text-white/60">Secure Multi-Portal Access</p>
        </motion.div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mb-6">
          {tabs.map((tab) => (
            <motion.button
              key={tab.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveTab(tab.id)}
              className="flex-1 relative"
            >
              {/* Liquid ripple transition effect */}
              {activeTab === tab.id && (
                <motion.div
                  layoutId="activeTab"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  className="absolute inset-0 bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-sm rounded-2xl border-2 border-[#50C878]/50"
                  style={{
                    boxShadow: "0 0 30px rgba(80, 200, 120, 0.4)",
                  }}
                />
              )}
              <div className="relative z-10 py-4 px-3 flex flex-col items-center gap-2">
                <tab.icon
                  className={`w-6 h-6 transition-colors ${
                    activeTab === tab.id ? "text-[#90EE90]" : "text-white/50"
                  }`}
                />
                <span
                  className={`text-xs transition-colors ${
                    activeTab === tab.id ? "text-white" : "text-white/50"
                  }`}
                >
                  {tab.label}
                </span>
              </div>
            </motion.button>
          ))}
        </div>

        {/* Login Forms */}
        <motion.div
          animate={{
            boxShadow: [
              "0 0 40px rgba(80, 200, 120, 0.2)",
              "0 0 60px rgba(80, 200, 120, 0.3)",
              "0 0 40px rgba(80, 200, 120, 0.2)",
            ],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="bg-white/5 backdrop-blur-xl border-2 border-white/20 rounded-3xl p-8"
        >
          <AnimatePresence mode="wait">
            {activeTab === "citizen" && (
              <motion.div
                key="citizen"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl text-white mb-6">
                  Citizen Portal Login
                </h2>

                {!showOTP ? (
                  <>
                    <div className="mb-6">
                      <label className="block text-white/70 text-sm mb-2">
                        Mobile Number
                      </label>
                      <input
                        type="tel"
                        maxLength={10}
                        value={citizenPhone}
                        onChange={(e) =>
                          setCitizenPhone(e.target.value.replace(/\D/g, ""))
                        }
                        placeholder="Enter 10-digit mobile number"
                        className="w-full bg-white/5 backdrop-blur-sm border-2 border-white/20 focus:border-[#90EE90] rounded-xl px-4 py-3 text-white placeholder-white/40 outline-none transition-all"
                      />
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleCitizenLogin}
                      disabled={citizenPhone.length !== 10}
                      className={`w-full py-4 rounded-2xl text-white transition-all ${
                        citizenPhone.length === 10
                          ? "bg-gradient-to-r from-[#90EE90] to-[#50C878] shadow-lg"
                          : "bg-white/10 cursor-not-allowed opacity-50"
                      }`}
                    >
                      Send OTP
                    </motion.button>
                  </>
                ) : (
                  <>
                    <div className="mb-6">
                      <label className="block text-white/70 text-sm mb-2">
                        Enter OTP
                      </label>
                      <input
                        type="text"
                        maxLength={6}
                        value={otp}
                        onChange={(e) =>
                          setOTP(e.target.value.replace(/\D/g, ""))
                        }
                        placeholder="6-digit OTP"
                        className="w-full bg-white/5 backdrop-blur-sm border-2 border-[#90EE90] rounded-xl px-4 py-3 text-white text-center text-2xl tracking-widest placeholder-white/40 outline-none"
                        style={{
                          boxShadow: "0 0 20px rgba(144, 238, 144, 0.3)",
                        }}
                      />
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleOTPVerify}
                      disabled={otp.length !== 6}
                      className={`w-full py-4 rounded-2xl text-white mb-3 transition-all ${
                        otp.length === 6
                          ? "bg-gradient-to-r from-[#90EE90] to-[#50C878] shadow-lg"
                          : "bg-white/10 cursor-not-allowed opacity-50"
                      }`}
                    >
                      Verify & Login
                    </motion.button>

                    <button
                      onClick={() => {
                        setShowOTP(false);
                        setOTP("");
                      }}
                      className="w-full text-white/60 text-sm hover:text-white transition-colors"
                    >
                      Change Number
                    </button>
                  </>
                )}
              </motion.div>
            )}

            {activeTab === "worker" && (
              <motion.div
                key="worker"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl text-white mb-6">
                  Service Worker Portal
                </h2>

                <div className="mb-6">
                  <label className="block text-white/70 text-sm mb-2">
                    Worker ID
                  </label>
                  <input
                    type="text"
                    value={workerID}
                    onChange={(e) => setWorkerID(e.target.value)}
                    placeholder="Enter your Worker ID"
                    className="w-full bg-white/5 backdrop-blur-sm border-2 border-white/20 focus:border-[#50C878] rounded-xl px-4 py-3 text-white placeholder-white/40 outline-none transition-all"
                  />
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full mb-4 py-4 bg-gradient-to-r from-white/10 to-white/5 backdrop-blur-sm border border-[#50C878]/40 rounded-2xl flex items-center justify-center gap-3 text-white"
                >
                  <QrCode className="w-6 h-6 text-[#50C878]" />
                  <span>Scan Identity Badge</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleWorkerLogin}
                  disabled={!workerID}
                  className={`w-full py-4 rounded-2xl text-white transition-all ${
                    workerID
                      ? "bg-gradient-to-r from-[#50C878] to-[#90EE90] shadow-lg"
                      : "bg-white/10 cursor-not-allowed opacity-50"
                  }`}
                >
                  Login
                </motion.button>
              </motion.div>
            )}

            {activeTab === "admin" && (
              <motion.div
                key="admin"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl text-white mb-6">
                  Admin Command Center
                </h2>

                <div className="mb-6">
                  <label className="block text-white/70 text-sm mb-2">
                    Government ID
                  </label>
                  <input
                    type="text"
                    value={adminID}
                    onChange={(e) => setAdminID(e.target.value)}
                    placeholder="Enter your Gov-ID"
                    className="w-full bg-white/5 backdrop-blur-sm border-2 border-white/20 focus:border-[#50C878] rounded-xl px-4 py-3 text-white placeholder-white/40 outline-none transition-all"
                  />
                </div>

                {/* Biometric Scanner */}
                <motion.div
                  animate={{
                    boxShadow: [
                      "0 0 20px rgba(80, 200, 120, 0.3)",
                      "0 0 40px rgba(80, 200, 120, 0.5)",
                      "0 0 20px rgba(80, 200, 120, 0.3)",
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                  className="mb-6 p-8 bg-gradient-to-br from-[#50C878]/10 to-[#90EE90]/5 backdrop-blur-sm border-2 border-[#50C878]/40 rounded-2xl flex flex-col items-center"
                >
                  <motion.div
                    animate={{
                      scale: [1, 1.1, 1],
                      rotate: [0, 5, -5, 0],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                    }}
                  >
                    <Fingerprint className="w-24 h-24 text-[#50C878] mb-4" />
                  </motion.div>
                  <p className="text-white text-sm">Place finger on scanner</p>
                  <p className="text-white/50 text-xs mt-1">
                    Biometric authentication required
                  </p>
                </motion.div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={handleAdminLogin}
                  disabled={!adminID}
                  className={`w-full py-4 rounded-2xl text-white transition-all ${
                    adminID
                      ? "bg-gradient-to-r from-[#50C878] to-[#90EE90] shadow-lg"
                      : "bg-white/10 cursor-not-allowed opacity-50"
                  }`}
                >
                  Secure Login
                </motion.button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Footer */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white/50 text-sm mt-6"
        >
          Secured by Clean Touch Authentication System
        </motion.p>
      </div>
    </div>
  );
}
