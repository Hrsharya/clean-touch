import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowLeft,
  MapPin,
  Camera,
  CheckCircle2,
  Navigation,
  Clock,
  Award,
  TrendingUp,
  Star,
} from "lucide-react";
import { useNavigate } from "react-router";

interface Task {
  id: string;
  location: string;
  coordinates: { lat: number; lng: number };
  priority: "high" | "medium" | "low";
  description: string;
  distance: string;
  reportedTime: string;
}

export function CleanerPortal() {
  const navigate = useNavigate();
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showCapture, setShowCapture] = useState(false);
  const [showImpact, setShowImpact] = useState(false);
  const [captureProgress, setCaptureProgress] = useState(0);
  const [currentLocation, setCurrentLocation] = useState("Locating...");
  const [resolvedThisMonth, setResolvedThisMonth] = useState(0);

  // Mock tasks data
  const tasks: Task[] = [
    {
      id: "1",
      location: "Park Avenue & 5th St",
      coordinates: { lat: 40.7589, lng: -73.9851 },
      priority: "high",
      description: "Overflowing trash bin near playground",
      distance: "0.3 km",
      reportedTime: "15 min ago",
    },
    {
      id: "2",
      location: "Central Square",
      coordinates: { lat: 40.7614, lng: -73.9776 },
      priority: "medium",
      description: "Litter scattered around fountain",
      distance: "0.8 km",
      reportedTime: "1 hour ago",
    },
    {
      id: "3",
      location: "Beach Front Promenade",
      coordinates: { lat: 40.7489, lng: -73.9680 },
      priority: "low",
      description: "General cleanup needed",
      distance: "1.5 km",
      reportedTime: "3 hours ago",
    },
  ];

  // Animate resolved count
  useEffect(() => {
    let count = 0;
    const target = 47;
    const interval = setInterval(() => {
      count += 1;
      setResolvedThisMonth(count);
      if (count >= target) clearInterval(interval);
    }, 30);
    return () => clearInterval(interval);
  }, []);

  // Simulate geo-location ticker
  useEffect(() => {
    const locations = [
      "40.7589°N, 73.9851°W",
      "40.7590°N, 73.9850°W",
      "40.7591°N, 73.9849°W",
    ];
    let index = 0;
    const interval = setInterval(() => {
      setCurrentLocation(locations[index]);
      index = (index + 1) % locations.length;
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleCaptureClean = () => {
    setShowCapture(true);
    // Simulate capture and upload
    let progress = 0;
    const interval = setInterval(() => {
      progress += 20;
      setCaptureProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setShowCapture(false);
          setSelectedTask(null);
          setCaptureProgress(0);
          setShowImpact(true);
        }, 1000);
      }
    }, 300);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "#FF6B6B";
      case "medium":
        return "#FFB84D";
      default:
        return "#90EE90";
    }
  };

  return (
    <div className="min-h-screen bg-[#0A192F] relative overflow-hidden">
      {/* Map Background - Simulated with markers */}
      <div className="absolute inset-0 bg-[#0D1F38]">
        {/* Grid pattern to simulate map */}
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                             linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />

        {/* Hotspot markers on map */}
        {tasks.map((task, index) => (
          <motion.div
            key={task.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: index * 0.2 }}
            className="absolute"
            style={{
              left: `${20 + index * 25}%`,
              top: `${30 + index * 15}%`,
            }}
          >
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: index * 0.3,
              }}
              className="relative"
            >
              {/* Pulsing ring */}
              <motion.div
                animate={{
                  scale: [1, 2, 1],
                  opacity: [0.6, 0, 0.6],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: index * 0.3,
                }}
                className="absolute inset-0 rounded-full"
                style={{
                  border: `2px solid ${getPriorityColor(task.priority)}`,
                }}
              />

              {/* Marker pin */}
              <motion.div
                whileHover={{ scale: 1.2 }}
                onClick={() => setSelectedTask(task)}
                className="w-12 h-12 rounded-full flex items-center justify-center cursor-pointer"
                style={{
                  background: `radial-gradient(circle, ${getPriorityColor(
                    task.priority
                  )}40, ${getPriorityColor(task.priority)}20)`,
                  border: `3px solid ${getPriorityColor(task.priority)}`,
                  boxShadow: `0 0 20px ${getPriorityColor(task.priority)}80`,
                }}
              >
                <MapPin
                  className="w-6 h-6"
                  style={{ color: getPriorityColor(task.priority) }}
                />
              </motion.div>
            </motion.div>
          </motion.div>
        ))}
      </div>

      {/* Header */}
      <div className="relative z-10 p-4 bg-gradient-to-b from-[#0A192F] to-transparent">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate("/")}
              className="p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </motion.button>
            <div>
              <h1 className="text-xl text-white">Service Portal</h1>
              <p className="text-white/60 text-sm">Active Tasks</p>
            </div>
          </div>

          <motion.div
            animate={{
              boxShadow: [
                "0 0 10px rgba(80, 200, 120, 0.4)",
                "0 0 20px rgba(80, 200, 120, 0.6)",
                "0 0 10px rgba(80, 200, 120, 0.4)",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="px-3 py-2 rounded-xl bg-[#50C878]/20 border border-[#50C878]/40 flex items-center gap-2"
          >
            <div className="w-2 h-2 rounded-full bg-[#50C878]" />
            <span className="text-white text-sm">Online</span>
          </motion.div>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl px-3 py-2 text-center">
            <div className="text-[#50C878] text-lg">12</div>
            <div className="text-white/60 text-xs">Today</div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl px-3 py-2 text-center">
            <div className="text-[#90EE90] text-lg">3</div>
            <div className="text-white/60 text-xs">Active</div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl px-3 py-2 text-center">
            <div className="text-white text-lg">98%</div>
            <div className="text-white/60 text-xs">Rating</div>
          </div>
        </div>
      </div>

      {/* Task Slide-up Panel */}
      <AnimatePresence>
        {selectedTask && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-[#0A192F]/60 backdrop-blur-sm z-20"
              onClick={() => setSelectedTask(null)}
            />

            {/* Panel */}
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 z-30 bg-[#0A192F] border-t-4 border-white/20 rounded-t-3xl p-6 max-h-[70vh] overflow-y-auto"
            >
              {/* Handle bar */}
              <div className="w-12 h-1 bg-white/30 rounded-full mx-auto mb-6" />

              <div className="mb-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="text-2xl text-white mb-2">
                      {selectedTask.location}
                    </h2>
                    <div className="flex items-center gap-2 text-white/60 text-sm mb-2">
                      <Clock className="w-4 h-4" />
                      <span>{selectedTask.reportedTime}</span>
                    </div>
                    <div className="flex items-center gap-2 text-white/60 text-sm">
                      <Navigation className="w-4 h-4" />
                      <span>{selectedTask.distance} away</span>
                    </div>
                  </div>
                  <span
                    className="px-3 py-1 rounded-full text-sm border-2"
                    style={{
                      backgroundColor: `${getPriorityColor(selectedTask.priority)}20`,
                      color: getPriorityColor(selectedTask.priority),
                      borderColor: `${getPriorityColor(selectedTask.priority)}40`,
                    }}
                  >
                    {selectedTask.priority.toUpperCase()}
                  </span>
                </div>

                <p className="text-white/80 mb-6">{selectedTask.description}</p>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleCaptureClean}
                    className="w-full bg-gradient-to-r from-[#50C878] to-[#90EE90] rounded-2xl py-4 flex items-center justify-center gap-3 text-white shadow-lg"
                  >
                    <Camera className="w-6 h-6" />
                    <span className="text-lg">Capture Clean</span>
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full bg-white/5 border border-white/20 rounded-2xl py-4 flex items-center justify-center gap-3 text-white"
                  >
                    <Navigation className="w-5 h-5" />
                    <span>Navigate</span>
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Capture Progress Overlay */}
      <AnimatePresence>
        {showCapture && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#0A192F]/95 backdrop-blur-xl z-40 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="text-center"
            >
              {captureProgress < 100 ? (
                <>
                  <Camera className="w-24 h-24 text-[#90EE90] mx-auto mb-6" />
                  <h3 className="text-2xl text-white mb-4">Processing...</h3>
                  
                  {/* Emerald progress sweep */}
                  <div className="w-64 h-2 bg-white/10 rounded-full overflow-hidden mx-auto">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${captureProgress}%` }}
                      className="h-full bg-gradient-to-r from-[#50C878] to-[#90EE90]"
                      style={{
                        boxShadow: "0 0 10px rgba(80, 200, 120, 0.8)",
                      }}
                    />
                  </div>
                  <p className="text-white/60 mt-4">{captureProgress}%</p>
                </>
              ) : (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                >
                  <CheckCircle2 className="w-24 h-24 text-[#50C878] mx-auto mb-4" />
                  <h3 className="text-2xl text-white">Task Complete!</h3>
                  <p className="text-[#90EE90] mt-2">Great work!</p>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Impact Overlay */}
      <AnimatePresence>
        {showImpact && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-[#0A192F]/95 backdrop-blur-xl z-40 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="text-center"
            >
              <Award className="w-24 h-24 text-[#FFB84D] mx-auto mb-6" />
              <h3 className="text-2xl text-white mb-4">Impactful Work!</h3>
              
              {/* Impact stats */}
              <div className="flex items-center justify-center gap-4 mt-4">
                <div className="text-center">
                  <TrendingUp className="w-6 h-6 text-[#50C878]" />
                  <p className="text-white/60 text-sm">Resolved This Month</p>
                  <div className="text-[#50C878] text-lg">{resolvedThisMonth}</div>
                </div>
                <div className="text-center">
                  <Star className="w-6 h-6 text-[#FFB84D]" />
                  <p className="text-white/60 text-sm">Rating</p>
                  <div className="text-[#FFB84D] text-lg">98%</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Geo-location Ticker */}
      <div className="fixed bottom-0 left-0 right-0 z-10 bg-[#0A192F]/90 backdrop-blur-sm border-t border-white/10 py-2 px-4">
        <div className="flex items-center justify-center gap-2">
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
            }}
          >
            <MapPin className="w-4 h-4 text-[#90EE90]" />
          </motion.div>
          <span className="text-white text-sm font-mono">{currentLocation}</span>
        </div>
      </div>
    </div>
  );
}