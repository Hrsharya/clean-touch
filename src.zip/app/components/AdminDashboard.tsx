import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Users,
  AlertCircle,
  CheckCircle2,
  TrendingUp,
  Activity,
} from "lucide-react";
import { useNavigate } from "react-router";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadialBarChart,
  RadialBar,
  Legend,
} from "recharts";

interface ActivityItem {
  id: string;
  message: string;
  user: string;
  timestamp: string;
  type: "report" | "clean" | "assign";
}

export function AdminDashboard() {
  const navigate = useNavigate();
  const [cleanlinessIndex, setCleanlinessIndex] = useState(0);
  const [activities, setActivities] = useState<ActivityItem[]>([
    {
      id: "1",
      message: "Area A Cleaned",
      user: "User 01",
      timestamp: "2 min ago",
      type: "clean",
    },
    {
      id: "2",
      message: "New Report Submitted",
      user: "User 23",
      timestamp: "5 min ago",
      type: "report",
    },
    {
      id: "3",
      message: "Task Assigned to Cleaner 12",
      user: "Admin",
      timestamp: "8 min ago",
      type: "assign",
    },
  ]);

  // Heatmap data - reports vs resolved
  const heatmapData = [
    { area: "Zone A", reports: 45, resolved: 42 },
    { area: "Zone B", reports: 32, resolved: 30 },
    { area: "Zone C", reports: 58, resolved: 52 },
    { area: "Zone D", reports: 28, resolved: 28 },
    { area: "Zone E", reports: 41, resolved: 38 },
  ];

  // Weekly trends
  const weeklyData = [
    { day: "Mon", reports: 42, resolved: 38 },
    { day: "Tue", reports: 38, resolved: 36 },
    { day: "Wed", reports: 45, resolved: 43 },
    { day: "Thu", reports: 52, resolved: 48 },
    { day: "Fri", reports: 48, resolved: 47 },
    { day: "Sat", reports: 35, resolved: 34 },
    { day: "Sun", relports: 28, resolved: 28 },
  ];

  // Cleanliness Index gauge data
  const gaugeData = [
    {
      name: "Cleanliness",
      value: 87,
      fill: "#50C878",
    },
  ];

  // Animate cleanliness index on mount
  useEffect(() => {
    let value = 0;
    const interval = setInterval(() => {
      value += 1;
      setCleanlinessIndex(value);
      if (value >= 87) clearInterval(interval);
    }, 20);
    return () => clearInterval(interval);
  }, []);

  // Simulate real-time activity updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newActivity: ActivityItem = {
        id: Date.now().toString(),
        message: "New Activity Detected",
        user: `User ${Math.floor(Math.random() * 100)}`,
        timestamp: "Just now",
        type: ["report", "clean", "assign"][Math.floor(Math.random() * 3)] as any,
      };
      setActivities((prev) => [newActivity, ...prev.slice(0, 9)]);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A192F] via-[#0D1F38] to-[#0A192F] p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate("/")}
              className="p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </motion.button>
            <div>
              <h1 className="text-3xl text-white mb-1">Command Center</h1>
              <p className="text-white/60">System Overview</p>
            </div>
          </div>

          <motion.div
            animate={{
              boxShadow: [
                "0 0 20px rgba(80, 200, 120, 0.3)",
                "0 0 30px rgba(80, 200, 120, 0.5)",
                "0 0 20px rgba(80, 200, 120, 0.3)",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="px-4 py-2 rounded-xl bg-[#50C878]/20 border border-[#50C878]/40 flex items-center gap-2"
          >
            <Activity className="w-5 h-5 text-[#90EE90]" />
            <span className="text-white">Live</span>
          </motion.div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Stats Cards */}
          <StatCard
            icon={<AlertCircle className="w-6 h-6" />}
            label="Active Reports"
            value="24"
            trend="-12%"
            color="#FFB84D"
          />
          <StatCard
            icon={<CheckCircle2 className="w-6 h-6" />}
            label="Resolved Today"
            value="156"
            trend="+8%"
            color="#50C878"
          />
          <StatCard
            icon={<Users className="w-6 h-6" />}
            label="Active Cleaners"
            value="42"
            trend="+3"
            color="#90EE90"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Cleanliness Index Gauge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-white/5 backdrop-blur-xl border border-[#50C878]/30 rounded-3xl p-6"
          >
            <h3 className="text-white text-lg mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#90EE90]" />
              Cleanliness Index
            </h3>

            <div className="relative">
              <ResponsiveContainer width="100%" height={250}>
                <RadialBarChart
                  cx="50%"
                  cy="50%"
                  innerRadius="70%"
                  outerRadius="90%"
                  data={gaugeData}
                  startAngle={180}
                  endAngle={0}
                >
                  <RadialBar
                    background
                    dataKey="value"
                    cornerRadius={10}
                    fill="#50C878"
                  />
                </RadialBarChart>
              </ResponsiveContainer>

              {/* Center value display */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, delay: 0.5 }}
                  className="text-center"
                >
                  <div className="text-6xl text-[#50C878] font-mono">
                    {cleanlinessIndex}
                  </div>
                  <div className="text-white/60 text-sm mt-2">
                    City Health Score
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Gauge description */}
            <div className="mt-4 p-4 bg-[#50C878]/10 rounded-xl border border-[#50C878]/20">
              <p className="text-white/80 text-sm">
                Excellent performance! The city cleanliness has improved by 15%
                this month.
              </p>
            </div>
          </motion.div>

          {/* Live Heatmap */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-white/5 backdrop-blur-xl border border-[#50C878]/30 rounded-3xl p-6"
          >
            <h3 className="text-white text-lg mb-4">Reports vs Resolved</h3>

            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={heatmapData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis
                  dataKey="area"
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <YAxis
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(10, 25, 47, 0.95)",
                    border: "1px solid rgba(80, 200, 120, 0.3)",
                    borderRadius: "12px",
                    backdropFilter: "blur(12px)",
                  }}
                  labelStyle={{ color: "#fff" }}
                />
                <Bar dataKey="reports" fill="#90EE90" radius={[8, 8, 0, 0]} />
                <Bar dataKey="resolved" fill="#50C878" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>

            <div className="flex gap-4 justify-center mt-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-[#90EE90]" />
                <span className="text-white/70 text-sm">Reports</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded bg-[#50C878]" />
                <span className="text-white/70 text-sm">Resolved</span>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Weekly Trends */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-2 bg-white/5 backdrop-blur-xl border border-[#50C878]/30 rounded-3xl p-6"
          >
            <h3 className="text-white text-lg mb-4">Weekly Activity</h3>

            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={weeklyData}>
                <defs>
                  <linearGradient id="colorReports" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#90EE90" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#90EE90" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#50C878" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#50C878" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis
                  dataKey="day"
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <YAxis
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(10, 25, 47, 0.95)",
                    border: "1px solid rgba(80, 200, 120, 0.3)",
                    borderRadius: "12px",
                    backdropFilter: "blur(12px)",
                  }}
                  labelStyle={{ color: "#fff" }}
                />
                <Area
                  type="monotone"
                  dataKey="reports"
                  stroke="#90EE90"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorReports)"
                />
                <Area
                  type="monotone"
                  dataKey="resolved"
                  stroke="#50C878"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorResolved)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </motion.div>

          {/* Real-time Activity Feed */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white/5 backdrop-blur-xl border border-[#50C878]/30 rounded-3xl p-6"
          >
            <h3 className="text-white text-lg mb-4 flex items-center gap-2">
              Activity Feed
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-2 h-2 rounded-full bg-[#50C878]"
              />
            </h3>

            <div className="space-y-3 max-h-[300px] overflow-y-auto custom-scrollbar">
              {activities.map((activity, index) => (
                <motion.div
                  key={activity.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="p-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl"
                >
                  <div className="flex items-start gap-2">
                    <div
                      className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                        activity.type === "clean"
                          ? "bg-[#50C878]"
                          : activity.type === "report"
                          ? "bg-[#FFB84D]"
                          : "bg-[#90EE90]"
                      }`}
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm">{activity.message}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-white/60 text-xs">
                          by {activity.user}
                        </span>
                        <span className="text-white/40 text-xs">•</span>
                        <span className="text-white/40 text-xs font-mono">
                          {activity.timestamp}
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(80, 200, 120, 0.3);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(80, 200, 120, 0.5);
        }
      `}</style>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  trend,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  trend: string;
  color: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{
        opacity: 1,
        y: 0,
        boxShadow: [
          `0 0 20px ${color}30`,
          `0 0 30px ${color}50`,
          `0 0 20px ${color}30`,
        ],
      }}
      whileHover={{ scale: 1.02, y: -2 }}
      transition={{
        boxShadow: {
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        },
      }}
      className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-2xl p-6"
    >
      <div className="flex items-start justify-between mb-4">
        <div
          className="p-3 rounded-xl backdrop-blur-sm"
          style={{ backgroundColor: `${color}20`, color }}
        >
          {icon}
        </div>
        <span
          className="text-sm px-2 py-1 rounded-lg"
          style={{
            backgroundColor: `${color}20`,
            color: color,
          }}
        >
          {trend}
        </span>
      </div>
      <div className="text-3xl text-white mb-1">{value}</div>
      <div className="text-white/60 text-sm">{label}</div>
    </motion.div>
  );
}