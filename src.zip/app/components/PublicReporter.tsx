import { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Camera, MapPin, TrendingUp, ArrowLeft, Upload } from "lucide-react";
import { useNavigate } from "react-router";

interface Report {
  id: string;
  location: string;
  beforeImage: string;
  afterImage?: string;
  status: "pending" | "resolved";
  timestamp: string;
}

export function PublicReporter() {
  const navigate = useNavigate();
  const [showUpload, setShowUpload] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [ripplePosition, setRipplePosition] = useState({ x: 0, y: 0 });
  const [showRipple, setShowRipple] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Mock recent cleans data
  const [recentCleans] = useState<Report[]>([
    {
      id: "1",
      location: "Park Avenue & 5th St",
      beforeImage: "https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=400",
      afterImage: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=400",
      status: "resolved",
      timestamp: "2 hours ago",
    },
    {
      id: "2",
      location: "Central Square",
      beforeImage: "https://images.unsplash.com/photo-1605600659908-0ef719419d41?w=400",
      afterImage: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400",
      status: "resolved",
      timestamp: "5 hours ago",
    },
    {
      id: "3",
      location: "Beach Front",
      beforeImage: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?w=400",
      status: "pending",
      timestamp: "1 day ago",
    },
  ]);

  const handleReportClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setRipplePosition({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
    setShowRipple(true);
    
    setTimeout(() => {
      setShowUpload(true);
      setShowRipple(false);
    }, 600);
  };

  const handleFileSelect = () => {
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setUploadProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setShowUpload(false);
          setUploadProgress(0);
        }, 1000);
      }
    }, 200);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A192F] via-[#0D1F38] to-[#0A192F] overflow-hidden">
      {/* Animated Navy wave background */}
      <motion.div
        className="absolute inset-0 opacity-10"
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%"],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 50 Q 25 30, 50 50 T 100 50 V 100 H 0 Z' fill='%2350C878' opacity='0.3'/%3E%3C/svg%3E")`,
          backgroundSize: "200% 200%",
        }}
      />

      <div className="relative z-10 px-6 pt-12 pb-8 max-w-md mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-3">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate("/")}
              className="p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              <ArrowLeft className="w-5 h-5 text-white" />
            </motion.button>
            <div>
              <h1 className="text-2xl text-white">Report Waste</h1>
              <p className="text-white/60 text-sm">Make your area cleaner</p>
            </div>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-3 rounded-xl bg-[#50C878]/20 backdrop-blur-xl border border-[#50C878]/40"
          >
            <TrendingUp className="w-5 h-5 text-[#90EE90]" />
          </motion.button>
        </motion.div>

        {/* Main Report Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8 flex justify-center"
        >
          <button
            onClick={handleReportClick}
            className="relative group"
          >
            <motion.div
              animate={{
                boxShadow: [
                  "0 0 30px rgba(144, 238, 144, 0.4)",
                  "0 0 50px rgba(144, 238, 144, 0.6)",
                  "0 0 30px rgba(144, 238, 144, 0.4)",
                ],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="w-64 h-64 rounded-full bg-white/5 backdrop-blur-xl border-4 border-[#90EE90] flex flex-col items-center justify-center relative overflow-hidden"
            >
              {/* Crystal ripple effect */}
              <AnimatePresence>
                {showRipple && (
                  <motion.div
                    initial={{ scale: 0, opacity: 0.8 }}
                    animate={{ scale: 4, opacity: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                    className="absolute w-20 h-20 rounded-full bg-gradient-to-r from-[#0A192F] via-[#90EE90] to-[#0A192F]"
                    style={{
                      left: ripplePosition.x,
                      top: ripplePosition.y,
                      transform: "translate(-50%, -50%)",
                    }}
                  />
                )}
              </AnimatePresence>

              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                <Camera className="w-20 h-20 text-[#90EE90] mb-4" />
              </motion.div>
              <span className="text-2xl text-white">Report Waste</span>
              <span className="text-sm text-white/60 mt-2">Tap to capture</span>
            </motion.div>
          </button>
        </motion.div>

        {/* Upload Modal */}
        <AnimatePresence>
          {showUpload && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-[#0A192F]/90 backdrop-blur-xl z-50 flex items-center justify-center px-6"
              onClick={() => setShowUpload(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-white/10 backdrop-blur-xl border-2 border-[#90EE90]/40 rounded-3xl p-8 max-w-sm w-full"
              >
                <h3 className="text-2xl text-white mb-4 text-center">Upload Photo</h3>
                
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handleFileSelect}
                />

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-gradient-to-r from-[#50C878]/30 to-[#90EE90]/20 backdrop-blur-sm border border-[#90EE90]/40 rounded-2xl p-8 mb-4"
                >
                  <Upload className="w-12 h-12 text-[#90EE90] mx-auto mb-2" />
                  <div className="text-white">Choose from gallery</div>
                  <div className="text-white/60 text-sm mt-1">or take a photo</div>
                </motion.button>

                {uploadProgress > 0 && (
                  <div className="mb-4">
                    <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${uploadProgress}%` }}
                        className="h-full bg-gradient-to-r from-[#90EE90] to-[#50C878]"
                      />
                    </div>
                    <div className="text-center text-[#90EE90] text-sm mt-2">
                      Uploading... {uploadProgress}%
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => setShowUpload(false)}
                    className="flex-1 py-3 rounded-xl bg-white/5 text-white/70 hover:bg-white/10 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Recent Cleans Feed */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-white/90 mb-4 flex items-center gap-2">
            <span>Recent Cleans</span>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-2 h-2 rounded-full bg-[#50C878]"
            />
          </h2>

          <div className="space-y-4">
            {recentCleans.map((report, index) => (
              <RecentCleanCard key={report.id} report={report} delay={index * 0.1} />
            ))}
          </div>
        </motion.div>

        {/* My Impact Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="fixed bottom-6 right-6 w-16 h-16 rounded-full bg-gradient-to-br from-[#50C878] to-[#90EE90] shadow-2xl flex items-center justify-center z-40"
        >
          <motion.div
            animate={{
              boxShadow: [
                "0 0 20px rgba(144, 238, 144, 0.6)",
                "0 0 30px rgba(144, 238, 144, 0.8)",
                "0 0 20px rgba(144, 238, 144, 0.6)",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute inset-0 rounded-full"
          />
          <TrendingUp className="w-7 h-7 text-white relative z-10" />
        </motion.button>
      </div>
    </div>
  );
}

function RecentCleanCard({ report, delay }: { report: Report; delay: number }) {
  const [showAfter, setShowAfter] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay }}
      whileHover={{ scale: 1.02 }}
      className="bg-white/5 backdrop-blur-xl border border-white/20 rounded-2xl p-4 cursor-pointer"
      onClick={() => report.afterImage && setShowAfter(!showAfter)}
    >
      <div className="flex gap-4">
        {/* Image with flip animation */}
        <div className="relative w-24 h-24 flex-shrink-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={showAfter ? "after" : "before"}
              initial={{ rotateY: 90, opacity: 0 }}
              animate={{ rotateY: 0, opacity: 1 }}
              exit={{ rotateY: -90, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute inset-0"
            >
              <img
                src={showAfter && report.afterImage ? report.afterImage : report.beforeImage}
                alt={showAfter ? "After" : "Before"}
                className="w-full h-full object-cover rounded-xl"
                style={{
                  filter: showAfter
                    ? "sepia(0.2) hue-rotate(60deg) saturate(1.2)"
                    : "sepia(0.3) hue-rotate(200deg) saturate(0.8)",
                }}
              />
              {/* Tint overlay */}
              <div
                className="absolute inset-0 rounded-xl mix-blend-overlay"
                style={{
                  background: showAfter
                    ? "linear-gradient(135deg, rgba(80, 200, 120, 0.3), rgba(144, 238, 144, 0.2))"
                    : "linear-gradient(135deg, rgba(10, 25, 47, 0.3), rgba(13, 31, 56, 0.2))",
                }}
              />
            </motion.div>
          </AnimatePresence>

          {/* Status badge */}
          {report.status === "resolved" && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-2 -right-2 w-6 h-6 bg-[#50C878] rounded-full flex items-center justify-center border-2 border-[#0A192F]"
            >
              <span className="text-white text-xs">✓</span>
            </motion.div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <h3 className="text-white text-sm truncate">{report.location}</h3>
            {report.afterImage && (
              <motion.div
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-[#90EE90] text-xs"
              >
                Tap to flip
              </motion.div>
            )}
          </div>
          
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="w-3 h-3 text-white/50" />
            <span className="text-white/60 text-xs">{report.timestamp}</span>
          </div>

          <div className="flex gap-2">
            <span
              className={`text-xs px-2 py-1 rounded-full ${
                report.status === "resolved"
                  ? "bg-[#50C878]/20 text-[#50C878] border border-[#50C878]/30"
                  : "bg-[#90EE90]/20 text-[#90EE90] border border-[#90EE90]/30"
              }`}
            >
              {report.status === "resolved" ? "Cleaned" : "Pending"}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
