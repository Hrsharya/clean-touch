import { motion } from "motion/react";
import { Droplet } from "lucide-react";

interface WaterDropletProps {
  purityLevel: number;
  isFlowing: boolean;
}

export function WaterDroplet({ purityLevel, isFlowing }: WaterDropletProps) {
  return (
    <div className="relative flex flex-col items-center justify-center">
      {/* Outer glow ring */}
      <motion.div
        animate={{
          scale: isFlowing ? [1, 1.1, 1] : 1,
          opacity: isFlowing ? [0.5, 0.8, 0.5] : 0.3,
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute w-48 h-48 rounded-full bg-emerald-400/20 blur-3xl"
      />

      {/* Main droplet container */}
      <motion.div
        animate={{
          y: isFlowing ? [-2, 2, -2] : 0,
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="relative"
      >
        {/* Glass-morphism circle */}
        <div className="relative w-40 h-40 rounded-full bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-xl border-2 border-emerald-400/40 shadow-2xl flex items-center justify-center">
          {/* Inner glow */}
          <motion.div
            animate={{
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute inset-4 rounded-full bg-gradient-to-br from-emerald-400/30 to-transparent blur-xl"
          />

          {/* Droplet icon */}
          <motion.div
            animate={{
              scale: isFlowing ? [1, 1.05, 1] : 1,
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="relative z-10"
          >
            <Droplet className="w-16 h-16 text-emerald-400 fill-emerald-400/20" />
          </motion.div>

          {/* Liquid physics effect - small droplets */}
          {isFlowing && (
            <>
              {[...Array(3)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ y: 0, opacity: 0 }}
                  animate={{
                    y: [0, 60],
                    opacity: [0, 1, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    delay: i * 0.6,
                    ease: "easeIn",
                  }}
                  className="absolute bottom-0 w-2 h-2 rounded-full bg-emerald-400/60 blur-sm"
                  style={{ left: `${40 + i * 10}%` }}
                />
              ))}
            </>
          )}
        </div>

        {/* Purity percentage display */}
        <motion.div
          animate={{
            opacity: [0.9, 1, 0.9],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute inset-0 flex flex-col items-center justify-center"
        >
          <div className="text-5xl text-white">{purityLevel}%</div>
          <div className="text-sm text-emerald-400 mt-1">Pure</div>
        </motion.div>
      </motion.div>

      {/* Status text */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-6 text-center"
      >
        <div className="text-white/90 text-lg">Filtration Active</div>
        <div className="text-white/50 text-sm mt-1">
          {isFlowing ? "Water flowing..." : "Ready to dispense"}
        </div>
      </motion.div>
    </div>
  );
}
