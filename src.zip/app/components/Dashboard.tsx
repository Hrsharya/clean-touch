import { useState } from "react";
import { motion } from "motion/react";
import { Droplet, Activity, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router";
import { TemperatureSlider } from "./TemperatureSlider";
import { WaterDroplet } from "./WaterDroplet";
import { FlowRateToggle } from "./FlowRateToggle";
import { QuickPresets } from "./QuickPresets";

export function Dashboard() {
  const navigate = useNavigate();
  const [temperature, setTemperature] = useState(18);
  const [isFlowing, setIsFlowing] = useState(false);
  const [flowRate, setFlowRate] = useState(2.5);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1628] via-[#0D1B32] to-[#0A1628] overflow-hidden relative">
      {/* Caustic water light effect background */}
      <motion.div
        className="absolute inset-0 opacity-20"
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, rgba(16, 185, 129, 0.3) 0%, transparent 50%),
                           radial-gradient(circle at 80% 50%, rgba(52, 211, 153, 0.2) 0%, transparent 50%)`,
          backgroundSize: "200% 200%",
        }}
      />

      {/* Main Content */}
      <div className="relative z-10 px-6 pt-12 pb-8 max-w-md mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-3xl text-white">Clean Tap</h1>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate("/data")}
              className="p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20"
            >
              <Activity className="w-5 h-5 text-emerald-400" />
            </motion.button>
          </div>
          <p className="text-white/60 text-sm">Ultra-pure water on demand</p>
        </motion.div>

        {/* Main Water Droplet Display */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <WaterDroplet purityLevel={99} isFlowing={isFlowing} />
        </motion.div>

        {/* Glass Panel Container */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-4"
        >
          {/* Temperature Control */}
          <div className="relative group">
            <motion.div
              animate={{
                boxShadow: [
                  "0 0 20px rgba(16, 185, 129, 0.3)",
                  "0 0 30px rgba(16, 185, 129, 0.5)",
                  "0 0 20px rgba(16, 185, 129, 0.3)",
                ],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="bg-white/5 backdrop-blur-xl border border-emerald-400/30 rounded-3xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white/90 text-sm">Temperature Control</h3>
                <span className="text-emerald-400 text-xl">
                  {temperature}°C
                </span>
              </div>
              <TemperatureSlider
                value={temperature}
                onChange={setTemperature}
              />
            </motion.div>
          </div>

          {/* Flow Rate Toggle */}
          <div className="relative">
            <motion.div
              animate={{
                boxShadow: isFlowing
                  ? [
                      "0 0 20px rgba(52, 211, 153, 0.3)",
                      "0 0 30px rgba(52, 211, 153, 0.5)",
                      "0 0 20px rgba(52, 211, 153, 0.3)",
                    ]
                  : "0 0 10px rgba(16, 185, 129, 0.1)",
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="bg-white/5 backdrop-blur-xl border border-emerald-400/30 rounded-3xl p-6"
            >
              <FlowRateToggle
                isFlowing={isFlowing}
                flowRate={flowRate}
                onToggle={setIsFlowing}
                onFlowRateChange={setFlowRate}
              />
            </motion.div>
          </div>

          {/* Quick Presets */}
          <QuickPresets onSelect={(preset) => setIsFlowing(true)} />

          {/* View Analytics Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate("/data")}
            className="w-full bg-gradient-to-r from-emerald-500/20 to-emerald-400/20 backdrop-blur-xl border border-emerald-400/30 rounded-2xl p-4 flex items-center justify-between group"
          >
            <span className="text-white/90">View Water Analytics</span>
            <ChevronRight className="w-5 h-5 text-emerald-400 group-hover:translate-x-1 transition-transform" />
          </motion.button>
        </motion.div>

        {/* Status Indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 flex gap-4 justify-center"
        >
          <StatusIndicator label="Filter Health" value="98%" color="emerald" />
          <StatusIndicator label="TDS Level" value="12 ppm" color="green" />
        </motion.div>
      </div>
    </div>
  );
}

function StatusIndicator({
  label,
  value,
  color,
}: {
  label: string;
  value: string;
  color: "emerald" | "green";
}) {
  const colorClass = color === "emerald" ? "text-emerald-400" : "text-green-400";
  
  return (
    <div className="flex flex-col items-center">
      <motion.div
        animate={{
          opacity: [0.7, 1, 0.7],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className={`text-sm ${colorClass} mb-1`}
      >
        {value}
      </motion.div>
      <div className="text-xs text-white/50">{label}</div>
    </div>
  );
}
