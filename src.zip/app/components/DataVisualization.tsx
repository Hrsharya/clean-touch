import { motion } from "motion/react";
import { ArrowLeft, Droplet, Filter, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadialBarChart,
  RadialBar,
  PolarAngleAxis,
} from "recharts";

export function DataVisualization() {
  const navigate = useNavigate();

  // Mock data for weekly water consumption
  const weeklyData = [
    { day: "Mon", liters: 18.5 },
    { day: "Tue", liters: 22.3 },
    { day: "Wed", liters: 19.8 },
    { day: "Thu", liters: 25.1 },
    { day: "Fri", liters: 21.4 },
    { day: "Sat", liters: 28.6 },
    { day: "Sun", liters: 24.2 },
  ];

  // Filter health data
  const filterHealthData = [
    { category: "Pre-Filter", health: 95, fill: "#10B981" },
    { category: "Carbon", health: 98, fill: "#34D399" },
    { category: "RO Membrane", health: 92, fill: "#6EE7B7" },
    { category: "Post-Filter", health: 97, fill: "#A7F3D0" },
  ];

  // Daily usage pattern
  const hourlyData = [
    { hour: "6AM", usage: 2.1 },
    { hour: "9AM", usage: 3.8 },
    { hour: "12PM", usage: 4.5 },
    { hour: "3PM", usage: 3.2 },
    { hour: "6PM", usage: 5.1 },
    { hour: "9PM", usage: 4.3 },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A1628] via-[#0D1B32] to-[#0A1628] overflow-hidden relative pb-8">
      {/* Background effects */}
      <motion.div
        className="absolute inset-0 opacity-20"
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, rgba(16, 185, 129, 0.3) 0%, transparent 50%),
                           radial-gradient(circle at 80% 50%, rgba(52, 211, 153, 0.2) 0%, transparent 50%)`,
          backgroundSize: "200% 200%",
        }}
      />

      {/* Content */}
      <div className="relative z-10 px-6 pt-12 max-w-md mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center mb-8"
        >
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/")}
            className="p-2 rounded-full bg-white/10 backdrop-blur-xl border border-white/20 mr-4"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </motion.button>
          <div>
            <h1 className="text-2xl text-white">Water Analytics</h1>
            <p className="text-white/60 text-sm">Your usage insights</p>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 gap-4 mb-6"
        >
          <StatCard
            icon={<Droplet className="w-5 h-5" />}
            label="Today's Usage"
            value="23.4L"
            trend="+8%"
            color="emerald"
          />
          <StatCard
            icon={<Filter className="w-5 h-5" />}
            label="Filter Health"
            value="98%"
            trend="Excellent"
            color="green"
          />
        </motion.div>

        {/* Weekly Consumption Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <ChartContainer title="Weekly Water Consumption">
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={weeklyData}>
                <defs>
                  <linearGradient id="colorLiters" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis
                  dataKey="day"
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <YAxis
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(10, 22, 40, 0.9)",
                    border: "1px solid rgba(16, 185, 129, 0.3)",
                    borderRadius: "12px",
                    backdropFilter: "blur(12px)",
                  }}
                  labelStyle={{ color: "#fff" }}
                />
                <Area
                  type="monotone"
                  dataKey="liters"
                  stroke="#10B981"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#colorLiters)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </ChartContainer>
        </motion.div>

        {/* Filter Health Visualization */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <ChartContainer title="Filter Life Health">
            <div className="space-y-4 py-4">
              {filterHealthData.map((filter, index) => (
                <FilterHealthBar
                  key={filter.category}
                  category={filter.category}
                  health={filter.health}
                  color={filter.fill}
                  delay={index * 0.1}
                />
              ))}
            </div>
          </ChartContainer>
        </motion.div>

        {/* Daily Usage Pattern */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-6"
        >
          <ChartContainer title="Today's Usage Pattern">
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={hourlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis
                  dataKey="hour"
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <YAxis
                  stroke="rgba(255,255,255,0.5)"
                  style={{ fontSize: "12px" }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "rgba(10, 22, 40, 0.9)",
                    border: "1px solid rgba(16, 185, 129, 0.3)",
                    borderRadius: "12px",
                    backdropFilter: "blur(12px)",
                  }}
                  labelStyle={{ color: "#fff" }}
                />
                <Line
                  type="monotone"
                  dataKey="usage"
                  stroke="#34D399"
                  strokeWidth={3}
                  dot={{ fill: "#34D399", r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </motion.div>

        {/* Insights Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-emerald-500/10 to-emerald-400/5 backdrop-blur-xl border border-emerald-400/30 rounded-3xl p-6"
        >
          <div className="flex items-start gap-3">
            <motion.div
              animate={{
                rotate: [0, 5, -5, 0],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <TrendingUp className="w-6 h-6 text-emerald-400" />
            </motion.div>
            <div>
              <h3 className="text-white/90 mb-2">Weekly Insights</h3>
              <p className="text-white/70 text-sm mb-3">
                Your water consumption increased by 12% this week. Filter replacement
                recommended in 45 days.
              </p>
              <div className="flex gap-2">
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-400 border border-emerald-400/30">
                  Healthy Usage
                </span>
                <span className="text-xs px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-400 border border-emerald-400/30">
                  Optimal TDS
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  trend,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  trend: string;
  color: "emerald" | "green";
}) {
  const colorClass = color === "emerald" ? "emerald-400" : "green-400";

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      animate={{
        boxShadow: [
          "0 0 20px rgba(16, 185, 129, 0.2)",
          "0 0 30px rgba(16, 185, 129, 0.3)",
          "0 0 20px rgba(16, 185, 129, 0.2)",
        ],
      }}
      transition={{
        boxShadow: {
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        },
      }}
      className="bg-white/5 backdrop-blur-xl border border-emerald-400/30 rounded-2xl p-4"
    >
      <div className={`text-${colorClass} mb-2`}>{icon}</div>
      <div className="text-2xl text-white mb-1">{value}</div>
      <div className="text-xs text-white/60 mb-1">{label}</div>
      <div className={`text-xs text-${colorClass}`}>{trend}</div>
    </motion.div>
  );
}

function ChartContainer({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      animate={{
        boxShadow: [
          "0 0 20px rgba(16, 185, 129, 0.2)",
          "0 0 30px rgba(16, 185, 129, 0.3)",
          "0 0 20px rgba(16, 185, 129, 0.2)",
        ],
      }}
      transition={{
        boxShadow: {
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        },
      }}
      className="bg-white/5 backdrop-blur-xl border border-emerald-400/30 rounded-3xl p-5"
    >
      <h3 className="text-white/90 text-sm mb-4">{title}</h3>
      {children}
    </motion.div>
  );
}

function FilterHealthBar({
  category,
  health,
  color,
  delay,
}: {
  category: string;
  health: number;
  color: string;
  delay: number;
}) {
  return (
    <div>
      <div className="flex justify-between mb-2">
        <span className="text-white/70 text-sm">{category}</span>
        <span className="text-emerald-400 text-sm">{health}%</span>
      </div>
      <div className="relative h-3 bg-white/10 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${health}%` }}
          transition={{ duration: 1, delay, ease: "easeOut" }}
          className="absolute inset-y-0 left-0 rounded-full"
          style={{
            background: `linear-gradient(90deg, ${color}, ${color}dd)`,
          }}
        >
          <motion.div
            animate={{
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="absolute inset-0 bg-white/20"
          />
        </motion.div>
      </div>
    </div>
  );
}
